global Animal, Colour, AnimalTopPointer, ColourTopPointer
Animal = [None for i in range(20)]    # Animal[] : string
Colour = [None for i in range(20)]    # Colour[] : string
AnimalTopPointer = 0    # AnimalTopPointer : integer
ColourTopPointer = 0    # ColourTopPointer : integer

def PushAnimal(DataToPush):    # DataToPush : string
    global Animal, AnimalTopPointer
    if AnimalTopPointer == 20:
        return False
    else:
        Animal[AnimalTopPointer] = DataToPush
        AnimalTopPointer = AnimalTopPointer + 1
        return True

def PopAnimal():
    global Animal, AnimalTopPointer
    if AnimalTopPointer == 0:
        return ""
    else:
        ReturnData = Animal[AnimalTopPointer - 1]    # ReturnData : string
        AnimalTopPointer = AnimalTopPointer - 1
        return ReturnData

def ReadData():
    try:
        AnimalData = open("AnimalData.txt", "r")
        for Line in AnimalData:    # Line : string
            PushAnimal(Line.strip())
        AnimalData.close()
    except IOError:
        print("File does not exist.")
    try:
        ColourData = open("ColourData.txt", "r")
        for Line in ColourData:
            PushColour(Line.strip())
        ColourData.close()
    except IOError:
        print("File does not exist.")

def PushColour(DataToPush):
    global Colour, ColourTopPointer
    if ColourTopPointer == 20:
        return False
    else:
        Colour[ColourTopPointer] = DataToPush
        ColourTopPointer = ColourTopPointer + 1
        return True

def PopColour():
    global Colour, ColourTopPointer
    if ColourTopPointer == 0:
        return ""
    else:
        ReturnData = Colour[ColourTopPointer - 1]
        ColourTopPointer = ColourTopPointer - 1
        return ReturnData

def OutputItem():
    global AnimalTopPointer, ColourTopPointer
    AnimalItem = PopAnimal()
    ColourItem = PopColour()
    if ColourItem == "":
        PushAnimal(AnimalItem)
        print("No colour")
    elif AnimalItem == "":
        PushColour(ColourItem)
        print("No animal")
    else:
        print(ColourItem, AnimalItem)

ReadData()
OutputItem()
OutputItem()
OutputItem()
OutputItem()
