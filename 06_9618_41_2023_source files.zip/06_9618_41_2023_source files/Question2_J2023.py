class Vehicle:

    def __init__(self, i, ms, ia):    # i : string, ms, ia : integer
        self.__ID = i    # ID : string
        self.__MaxSpeed = ms    # MaxSpeed : integer
        self.__CurrentSpeed = 0    # CurrentSpeed : integer
        self.__IncreaseAmount = ia    # IncreaseAmount : integer
        self.__HorizontalPosition = 0    # HorizontalPosition : integer

    def GetCurrentSpeed(self):
        return self.__CurrentSpeed

    def GetIncreaseAmount(self):
        return self.__IncreaseAmount

    def GetMaxSpeed(self):
        return self.__MaxSpeed

    def GetHorizontalPosition(self):
        return self.__HorizontalPosition

    def SetCurrentSpeed(self, cs):    # cs : integer
        self.__CurrentSpeed = cs

    def SetHorizontalPosition(self, hp):    # hp : integer
        self.__HorizontalPosition = hp

    def IncreaseSpeed(self):
        self.__CurrentSpeed = self.__CurrentSpeed + self.__IncreaseAmount
        if self.__CurrentSpeed > self.__MaxSpeed:
            self.__CurrentSpeed = self.__MaxSpeed
        self.__HorizontalPosition = self.__HorizontalPosition + self.__CurrentSpeed

    def Output(self):
        print("Horizontal position is", self.__HorizontalPosition)
        print("Speed is", self.__CurrentSpeed)

class Helicopter(Vehicle):

    def __init__(self, i, ms, ia, vc, mh):    # vc, mh : integer
        Vehicle.__init__(self, i, ms, ia)
        self.__VerticalPosition = 0    # VerticalPosition : integer
        self.__VerticalChange = vc    # VerticalChange : integer
        self.__MaxHeight = mh    # MaxHeight : integer

    def IncreaseSpeed(self):
        self.__VerticalPosition = self.__VerticalPosition + self.__VerticalChange
        if self.__VerticalPosition > self.__MaxHeight:
            self.__VerticalPosition = self.__MaxHeight
        Vehicle.IncreaseSpeed(self)

    def Output(self):
        print("Vertical position is", self.__VerticalPosition)
        Vehicle.Output(self)

# MAIN PROGRAM

NewCar = Vehicle("Tiger", 100, 20)
NewHelicopter = Helicopter("Lion", 350, 40, 3, 100)
NewCar.IncreaseSpeed()
NewCar.IncreaseSpeed()
NewCar.Output()
print()
NewHelicopter.IncreaseSpeed()
NewHelicopter.IncreaseSpeed()
NewHelicopter.Output()
