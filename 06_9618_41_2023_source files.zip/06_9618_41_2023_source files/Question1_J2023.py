def PrintArray(IntegerArray):    # IntegerArray[] : integer
    for PrintIndex in IntegerArray:    # PrintIndex : integer
        print(PrintIndex, end = " ")

def LinearSearch(IntegerArray, SearchValue):    # IntegerArray[], SearchValue : integer
    Count = 0    # Count : integer
    for TestValue in IntegerArray:    # TestValue : integer
        if TestValue == SearchValue:
            Count = Count + 1
    return Count

# MAIN PROGRAM

DataArray = []    # DataArray[0:24] : integer

try:
    Data = open("Data.txt", "r")
    for Index in Data:    # Index : integer
        DataArray.append(int(Index))
    Data.close()
except:
    print("Could not find file.")

PrintArray(DataArray)

Number = -1    # Number : integer
print()
while Number < 0 or Number > 100:
    Number = int(input("Input a number between 0 and 100 inclusive: "))
    if Number < 0 or Number > 100:
        print("Number is not within range.")
Result = LinearSearch(DataArray, Number)    # Result : integer
print("The number", Number, "is found", Result, "times.")
