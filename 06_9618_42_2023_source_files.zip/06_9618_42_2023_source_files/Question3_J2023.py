class Employee:

    def __init__(self, hp, en, jt):    # hp : real; en, jt : string
        self.__HourlyPay = hp    # HourlyPay : real
        self.__EmployeeNumber = en    # EmployeeNumber : string
        self.__JobTitle = jt    # JobTitle : string
        self.__PayYear2022 = [0.0 for Index in range(52)]    # PayYear2022[0:51] : real

    def GetEmployeeNumber(self):
        return self.__EmployeeNumber

    def SetPay(self, WeekNumber, NumberOfHours):    # WeekNumber : integer; NumberOfHours : real
        AmountPaid = self.__HourlyPay * NumberOfHours    # AmountPaid : real
        self.__PayYear2022[WeekNumber] = AmountPaid

    def GetTotalPay(self):
        Total = self.__PayYear2022[0]
        for Index in range(1, 52):
            Total = Total + self.__PayYear2022[Index]
        return Total

class Manager(Employee):

    def __init__(self, hp, en, jt, bv):    # bv : real
        Employee.__init__(self, hp, en, jt)
        self.__BonusValue = bv    # BonusValue : real

    def SetPay(self, WeekNumber, NumberOfHours):
        NumberOfHours = NumberOfHours + ((NumberOfHours / 100) * BonusValue)
        Employee.SetPay(self, WeekNumber, NumberOfHours)

def EnterHours():
    HoursFile = open("HoursWeek1.txt", "r")
    for Index in range(8):
        EmployeeNumber = HoursFile.readline()
        NumberOfHours = float(HoursFile.readline())
        for Index1 in range(8):
            if EmployeeNumber == EmployeeArray[Index1].GetEmployeeNumber():
                EmployeeArray[Index1].SetPay(1, NumberOfHours)
    HoursFile.close()

# MAIN PROGRAM

global EmployeeArray
EmployeeArray = []

try:
    EmployeeFile = open("Employees.txt", "r")
    
    for Index in range(8):
        HourlyPay = float(EmployeeFile.readline())
        EmployeeNumber = EmployeeFile.readline()
        Line = EmployeeFile.readline()
        
        try:
            BonusValue = float(Line)
            JobTitle = EmployeeFile.readline()
            EmployeeArray.append(Manager(HourlyPay, EmployeeNumber, JobTitle, BonusValue))
        except:
            JobTitle = Line
            EmployeeArray.append(Employee(HourlyPay, EmployeeNumber, JobTitle))
            
    EmployeeFile.close()
    
except IOError:
    print("File does not exist.")

EnterHours()
for Index in range(8):
    print("Employee with the number", EmployeeArray[Index].GetEmployeeNumber().strip(), "has a total pay of", EmployeeArray[Index].GetTotalPay())
