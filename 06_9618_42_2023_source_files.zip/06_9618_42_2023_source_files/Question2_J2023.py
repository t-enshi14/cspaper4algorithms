def Enqueue(NewRecord):    # NewRecord : SaleData
    global CircularQueue, Tail, NumberOfItems
    if NumberOfItems == 5:
        return -1
    else:
        CircularQueue[Tail] = NewRecord
        Tail = Tail + 1
        if Tail == 5:
            Tail = 0
        NumberOfItems = NumberOfItems + 1
        return 1

def Dequeue():
    global CircularQueue, Head, NumberOfItems
    if NumberOfItems == 0:
        return SaleData("", -1)
    else:
        Head = Head + 1
        if Head == 5:
            Head = 0
        NumberOfItems = NumberOfItems - 1
        return CircularQueue[Head]

def EnterRecord():
    ID = input("Enter an ID: ")    # ID : string
    Quantity = int(input("Enter quantity: "))    # Quantity : integer
    Result = Enqueue(SaleData(ID, Quantity))
    if Result == -1:
        print("Full")
    else:
        print("Stored")

# MAIN PROGRAM

class SaleData:

    def __init__(self, i, q):    # i : string, q : integer
        self.ID = i    # ID : string
        self.Quantity = q    # Quantity : integer

global CircularQueue, Head, Tail, NumberOfItems    # CircularQueue : SaleData, Head, Tail, NumberOfItems : integer
CircularQueue = [SaleData("", -1) for i in range(5)]
Head = 0
Tail = 0
NumberOfItems = 0

EnterRecord()
EnterRecord()
EnterRecord()
EnterRecord()
EnterRecord()
EnterRecord()
Result = Dequeue()
if Result == SaleData("", -1):
    print("Queue is empty.")
else:
    print(Result.ID)
EnterRecord()
print("ID  | Quantity")
for Item in CircularQueue:
    print(Item.ID, " ", Item.Quantity)
