global Animals

Animals = [None for i in range(10)]

def SortDescending():
    ArrayLength = len(Animals)    # ArrayLength : integer
    for X in range(0, ArrayLength - 1):
        for Y in range(0, ArrayLength - X - 1):
            if Animals[Y][0] < Animals[Y + 1][0]:
                Temp = Animals[Y]    # Temp : string
                Animals[Y] = Animals[Y + 1]
                Animals[Y + 1] = Temp

# MAIN PROGRAM

Animals[0] = "horse"
Animals[1] = "lion"
Animals[2] = "rabbit"
Animals[3] = "mouse"
Animals[4] = "bird"
Animals[5] = "deer"
Animals[6] = "whale"
Animals[7] = "elephant"
Animals[8] = "kangaroo"
Animals[9] = "tiger"

SortDescending()
for i in range(len(Animals)):
    print(Animals[i])
